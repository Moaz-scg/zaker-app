import 'package:flutter/material.dart';

void main() => runApp(const ZakerSmartApp());

const navy = Color(0xFF172554);
const blue = Color(0xFF3157D5);
const pale = Color(0xFFF4F6FC);
const green = Color(0xFF15966A);

class ZakerSmartApp extends StatelessWidget {
  const ZakerSmartApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ذاكر بذكاء',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        scaffoldBackgroundColor: pale,
        useMaterial3: true,
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: WelcomeFlow(),
      ),
    );
  }
}

class StudentProfile {
  String name = '';
  String age = '';
  String year = '';
  String goal = 'أعلى درجات ممكنة';
  String studyStyle = 'المهام';
}

class StudyTask {
  StudyTask({required this.subject, required this.title, this.done = false});
  final String subject;
  final String title;
  bool done;
}

class WelcomeFlow extends StatefulWidget {
  const WelcomeFlow({super.key});
  @override
  State<WelcomeFlow> createState() => _WelcomeFlowState();
}

class _WelcomeFlowState extends State<WelcomeFlow> {
  final profile = StudentProfile();
  final name = TextEditingController();
  final age = TextEditingController();
  final year = TextEditingController();
  int step = 0;

  @override
  void dispose() {
    name.dispose();
    age.dispose();
    year.dispose();
    super.dispose();
  }

  void next() {
    if (step == 0 && name.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب اسمك أو اسمًا تحب أن نناديك به')));
      return;
    }
    if (step == 0) profile.name = name.text.trim();
    if (step == 1) {
      profile.age = age.text.trim();
      profile.year = year.text.trim();
    }
    if (step < 3) {
      setState(() => step++);
    } else {
      profile.studyStyle = profile.studyStyle;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => PlannerHome(profile: profile)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final titles = ['أهلًا بيك في ذاكر بذكاء', 'خلينا نتعرف عليك', 'إيه هدفك من المذاكرة؟', 'تحب تنظم مذاكرتك إزاي؟'];
    return Scaffold(
      appBar: AppBar(title: const Text('ذاكر بذكاء'), centerTitle: false),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 12),
            const StudyIllustration(),
            const SizedBox(height: 18),
            Text(titles[step], style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: navy)),
            const SizedBox(height: 8),
            Text(
              [
                'مساعدك في تنظيم المذاكرة، ومتابعة تقدمك، وفهم دروسك. إنت اللي تختار النظام المناسب ليك.',
                'هنستخدم البيانات دي لتخصيص الخطة. تقدر تعدلها بعدين.',
                'اختيارك هيساعدنا نرتب الأولويات، لكن تقدر تغيّر هدفك في أي وقت.',
                'هنشرح لك كل نظام بمثال بسيط قبل ما تبدأ.',
              ][step],
              style: const TextStyle(fontSize: 15, color: Colors.black54, height: 1.5),
            ),
            const SizedBox(height: 22),
            if (step == 0) ...[
              TextField(controller: name, decoration: const InputDecoration(labelText: 'اسمك', hintText: 'مثال: معاذ', prefixIcon: Icon(Icons.person_outline), border: OutlineInputBorder())),
            ] else if (step == 1) ...[
              TextField(controller: age, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السن', hintText: 'مثال: 16', prefixIcon: Icon(Icons.cake_outlined), border: OutlineInputBorder())),
              const SizedBox(height: 14),
              TextField(controller: year, decoration: const InputDecoration(labelText: 'السنة الدراسية', hintText: 'مثال: أولى ثانوي، تالتة ثانوي، جامعة', prefixIcon: Icon(Icons.school_outlined), border: OutlineInputBorder())),
            ] else if (step == 2) ...[
              SelectCard(icon: Icons.emoji_events_outlined, title: 'أجيب أعلى درجات ممكنة', subtitle: 'تركيز على الفهم، التدريب، والمراجعة قبل الامتحانات', selected: profile.goal == 'أعلى درجات ممكنة', onTap: () => setState(() => profile.goal = 'أعلى درجات ممكنة')),
              SelectCard(icon: Icons.trending_up, title: 'أحسن مستوايا تدريجيًا', subtitle: 'أبني عادة مذاكرة ثابتة وأرفع درجاتي خطوة بخطوة', selected: profile.goal == 'تحسين المستوى', onTap: () => setState(() => profile.goal = 'تحسين المستوى')),
              SelectCard(icon: Icons.pending_actions, title: 'ألحق الدروس المتراكمة', subtitle: 'أرتب المتراكم مع متابعة الدروس الجديدة', selected: profile.goal == 'إنهاء المتراكم', onTap: () => setState(() => profile.goal = 'إنهاء المتراكم')),
              SelectCard(icon: Icons.menu_book_outlined, title: 'أفهم المواد وأثبت المعلومات', subtitle: 'شرح ومراجعة وأسئلة تناسب مستوايا', selected: profile.goal == 'الفهم والتثبيت', onTap: () => setState(() => profile.goal = 'الفهم والتثبيت')),
            ] else ...[
              SelectCard(icon: Icons.checklist, title: 'بالمهام', subtitle: 'مثال: ذاكر درس نحو، حل 15 سؤالًا، وراجع 10 كلمات. إنت تختار وقت التنفيذ.', selected: profile.studyStyle == 'المهام', onTap: () => setState(() => profile.studyStyle = 'المهام')),
              SelectCard(icon: Icons.schedule, title: 'بالساعات', subtitle: 'مثال: من 3:00 إلى 4:30 رياضيات، ومن 5:00 إلى 6:00 أحياء.', selected: profile.studyStyle == 'الساعات', onTap: () => setState(() => profile.studyStyle = 'الساعات')),
              const SizedBox(height: 8),
              const Text('تقدر تغيّر اختيارك في أي وقت من الإعدادات.', style: TextStyle(color: Colors.black54, fontSize: 13)),
            ],
            const SizedBox(height: 22),
            FilledButton(
              onPressed: next,
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
              child: Text(step == 3 ? 'ابدأ استخدام التطبيق' : 'التالي'),
            ),
            if (step > 0)
              TextButton(onPressed: () => setState(() => step--), child: const Text('رجوع')),
            const SizedBox(height: 12),
            Center(child: Text('الخطوة ${step + 1} من 4', style: const TextStyle(color: Colors.black45))),
          ],
        ),
      ),
    );
  }
}

class SelectCard extends StatelessWidget {
  const SelectCard({super.key, required this.icon, required this.title, required this.subtitle, required this.selected, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: selected ? const Color(0xFFE8EDFF) : Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: selected ? blue : Colors.black12, width: selected ? 1.5 : 1),
      ),
      child: ListTile(
        onTap: onTap,
        leading: Icon(icon, color: selected ? blue : Colors.black54, size: 28),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text(subtitle, style: const TextStyle(height: 1.4))),
        trailing: Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off, color: selected ? blue : Colors.black38),
      ),
    );
  }
}

class PlannerHome extends StatefulWidget {
  const PlannerHome({super.key, required this.profile});
  final StudentProfile profile;
  @override
  State<PlannerHome> createState() => _PlannerHomeState();
}

class _PlannerHomeState extends State<PlannerHome> {
  final List<StudyTask> tasks = [
    StudyTask(subject: 'رياضيات', title: 'مراجعة الجزء الذي تم شرحه'),
    StudyTask(subject: 'رياضيات', title: 'حل 10 أسئلة على الدرس'),
    StudyTask(subject: 'لغة عربية', title: 'مذاكرة درس نحو'),
    StudyTask(subject: 'أحياء', title: 'مراجعة الدرس السابق'),
  ];
  final subjectController = TextEditingController();
  final taskController = TextEditingController();
  final backlogController = TextEditingController();
  final hoursController = TextEditingController(text: '4');
  int tab = 0;
  int get completed => tasks.where((t) => t.done).length;
  int get progress => tasks.isEmpty ? 0 : ((completed / tasks.length) * 100).round();

  @override
  void dispose() {
    subjectController.dispose();
    taskController.dispose();
    backlogController.dispose();
    hoursController.dispose();
    super.dispose();
  }

  void addTask() {
    subjectController.clear();
    taskController.clear();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(20, 8, 20, MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('إضافة مهمة جديدة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          TextField(controller: subjectController, decoration: const InputDecoration(labelText: 'اسم المادة', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: taskController, decoration: const InputDecoration(labelText: 'المهمة', hintText: 'مثال: حل أسئلة الدرس', border: OutlineInputBorder())),
          const SizedBox(height: 14),
          FilledButton(
            onPressed: () {
              if (subjectController.text.trim().isEmpty || taskController.text.trim().isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب اسم المادة والمهمة')));
                return;
              }
              setState(() => tasks.add(StudyTask(subject: subjectController.text.trim(), title: taskController.text.trim())));
              Navigator.pop(ctx);
            },
            child: const Text('حفظ المهمة'),
          ),
        ]),
      ),
    );
  }

  void generatePlan() {
    final hours = int.tryParse(hoursController.text) ?? 4;
    final subjects = backlogController.text
        .split(RegExp(r'[,،\n]+'))
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty)
        .toList();
    if (hours < 1 || hours > 16 || subjects.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب موادك وعدد ساعات من 1 إلى 16')));
      return;
    }
    setState(() {
      tasks.removeWhere((t) => !t.done);
      for (int i = 0; i < hours.clamp(1, 6); i++) {
        final s = subjects[i % subjects.length];
        tasks.add(StudyTask(subject: s, title: i % 3 == 0 ? 'مذاكرة جزء من الدرس' : i % 3 == 1 ? 'حل أسئلة وتطبيق' : 'مراجعة ما سبق'));
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أنشأنا خطة مبدئية. راجعها وعدّلها حسب مواعيد دروسك.')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('ذاكر بذكاء', style: TextStyle(fontWeight: FontWeight.bold)),
          Text('أهلًا ${widget.profile.name}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
        ]),
        actions: [IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AssistantPage(profile: widget.profile))), icon: const Icon(Icons.auto_awesome), tooltip: 'المساعد الذكي')],
      ),
      body: IndexedStack(
        index: tab,
        children: [
          homeTab(),
          scheduleTab(),
          const ToolsTab(),
        ],
      ),
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(onPressed: addTask, icon: const Icon(Icons.add), label: const Text('مهمة جديدة')) : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'الجدول'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'أدواتي'),
        ],
      ),
    );
  }

  Widget homeTab() => ListView(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [navy, blue]), borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('خطوة بخطوة توصل لهدفك', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 5),
          Text(widget.profile.goal, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          Row(children: [
            Text('$progress%', style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.bold)),
            const Spacer(),
            Text('$completed من ${tasks.length} مهام', style: const TextStyle(color: Colors.white)),
          ]),
          const SizedBox(height: 10),
          ClipRRect(borderRadius: BorderRadius.circular(12), child: LinearProgressIndicator(value: tasks.isEmpty ? 0 : completed / tasks.length, minHeight: 8, color: Colors.white, backgroundColor: Colors.white30)),
        ]),
      ),
      const SizedBox(height: 18),
      Card(
        elevation: 0,
        child: ListTile(
          leading: const CircleAvatar(backgroundColor: Color(0xFFE8EDFF), child: Icon(Icons.auto_awesome, color: blue)),
          title: const Text('اسأل المساعد الذكي', style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: const Text('شرح، تلخيص، أسئلة، ومراجعة'),
          trailing: const Icon(Icons.chevron_left),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AssistantPage(profile: widget.profile))),
        ),
      ),
      const SizedBox(height: 12),
      Row(children: [
        const Expanded(child: Text('مهام اليوم', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        TextButton(onPressed: addTask, child: const Text('إضافة')),
      ]),
      if (tasks.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('مفيش مهام لسه. أضف مهمة أو أنشئ خطة مبدئية.'))),
      ...tasks.asMap().entries.map((entry) {
        final i = entry.key;
        final task = entry.value;
        return Card(
          elevation: 0,
          margin: const EdgeInsets.only(bottom: 8),
          child: CheckboxListTile(
            value: task.done,
            onChanged: (v) => setState(() => task.done = v ?? false),
            controlAffinity: ListTileControlAffinity.leading,
            title: Text(task.title, style: TextStyle(fontWeight: FontWeight.w600, decoration: task.done ? TextDecoration.lineThrough : null)),
            subtitle: Text(task.subject),
            secondary: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => setState(() => tasks.removeAt(i))),
          ),
        );
      }),
      const SizedBox(height: 12),
      const Text('أنشئ خطة مبدئية', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('اكتب المواد المتراكمة مفصولة بفواصل، وحدد وقتك المتاح.', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 10),
      TextField(controller: backlogController, maxLines: 2, decoration: const InputDecoration(labelText: 'المواد المتراكمة', hintText: 'نحو، فيزياء، أحياء، إنجليزي', border: OutlineInputBorder())),
      const SizedBox(height: 10),
      TextField(controller: hoursController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ساعات المذاكرة المتاحة', border: OutlineInputBorder(), prefixIcon: Icon(Icons.schedule))),
      const SizedBox(height: 10),
      FilledButton.icon(onPressed: generatePlan, icon: const Icon(Icons.auto_awesome), label: const Text('إنشاء خطة مبدئية')),
      const SizedBox(height: 8),
      const Text('تنبيه: الحسابات، الحفظ السحابي، الإشعارات الحقيقية والاتصال بنموذج ذكاء اصطناعي تحتاج إعدادات إضافية في المراحل القادمة.', style: TextStyle(fontSize: 12, color: Colors.black54)),
    ],
  );

  Widget scheduleTab() {
    final isTasks = widget.profile.studyStyle == 'المهام';
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text(isTasks ? 'خطة المهام' : 'جدول الساعات', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      Text(isTasks ? 'ركز على إنجاز المطلوب، واختار وقت التنفيذ بنفسك.' : 'مواعيد تجريبية قابلة للتعديل في النسخة القادمة.', style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 16),
      if (isTasks) ...[
        const SelectCard(icon: Icons.check_circle_outline, title: 'أنجز مهمة ثم انتقل للتالية', subtitle: 'مذاكرة درس، حل أسئلة، ثم مراجعة قصيرة.', selected: true, onTap: _noop),
        const SelectCard(icon: Icons.tips_and_updates_outlined, title: 'لو مهمة ما خلصتش', subtitle: 'انقلها لخطة لاحقة بدل ما تضغط على نفسك.', selected: false, onTap: _noop),
      ] else ...[
        const ScheduleRow(time: '3:00 – 4:30', title: 'رياضيات', detail: 'شرح وحل أسئلة', color: blue),
        const ScheduleRow(time: '4:30 – 5:00', title: 'وقت حر', detail: 'راحة أو ترتيب المكتب', color: green),
        const ScheduleRow(time: '5:00 – 6:00', title: 'أحياء', detail: 'مراجعة وحل تدريبات', color: Color(0xFFB7791F)),
      ],
      const SizedBox(height: 18),
      const Card(elevation: 0, child: Padding(padding: EdgeInsets.all(16), child: Text('المواعيد والتنبيهات هنا أمثلة توضيحية فقط؛ لم يتم تفعيل إشعارات النظام بعد.'))),
    ]);
  }
}

void _noop() {}

class ScheduleRow extends StatelessWidget {
  const ScheduleRow({super.key, required this.time, required this.title, required this.detail, required this.color});
  final String time, title, detail;
  final Color color;
  @override
  Widget build(BuildContext context) => Card(
    elevation: 0,
    margin: const EdgeInsets.only(bottom: 10),
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Row(children: [
        Container(width: 5, height: 58, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8))),
        const SizedBox(width: 12),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(time, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          Text(detail, style: const TextStyle(color: Colors.black54)),
        ]),
      ]),
    ),
  );
}

class ToolsTab extends StatelessWidget {
  const ToolsTab({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('أدوات المذاكرة', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('أدوات تساعدك تفهم وتراجع، مش مجرد جدول.', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 18),
      ToolCard(icon: Icons.auto_awesome, title: 'المساعد الذكي', subtitle: 'اسأل عن درس أو اطلب خطة مراجعة', onTap: (context) => Navigator.push(context, MaterialPageRoute(builder: (_) => AssistantPage(profile: StudentProfile())))),
      const ToolCard(icon: Icons.picture_as_pdf_outlined, title: 'ملفات PDF', subtitle: 'المخطط: ارفع ملزمة ليتم تلخيصها وإنشاء أسئلة منها', onTap: _comingSoon),
      const ToolCard(icon: Icons.quiz_outlined, title: 'اختبار سريع', subtitle: 'جرب نموذجًا تجريبيًا مع تصحيح فوري', onTap: (context) => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuizPage()))),
      const ToolCard(icon: Icons.notifications_active_outlined, title: 'التنبيهات', subtitle: 'تنبيه قبل موعد المذاكرة وعند بدايته', onTap: _comingSoon),
      const ToolCard(icon: Icons.draw_outlined, title: 'رسومات توضيحية', subtitle: 'مساحة للرسومات العلمية والتوضيحية؛ الخرائط الذهنية اختيار منفصل لاحقًا', onTap: _comingSoon),
    ],
  );
  static void _comingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الميزة موجودة في خطة التطوير، ولسه محتاجة ربط فعلي.')));
  }
}

class ToolCard extends StatelessWidget {
  const ToolCard({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title, subtitle;
  final void Function(BuildContext) onTap;
  @override
  Widget build(BuildContext context) => Card(
    elevation: 0,
    margin: const EdgeInsets.only(bottom: 10),
    child: ListTile(
      onTap: () => onTap(context),
      leading: CircleAvatar(backgroundColor: const Color(0xFFE8EDFF), child: Icon(icon, color: blue)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_left),
    ),
  );
}

class AssistantPage extends StatefulWidget {
  const AssistantPage({super.key, required this.profile});
  final StudentProfile profile;
  @override
  State<AssistantPage> createState() => _AssistantPageState();
}

class _AssistantPageState extends State<AssistantPage> {
  final input = TextEditingController();
  final messages = <String>[
    'أهلًا بيك! أنا المساعد الدراسي داخل التطبيق.',
    'تقدر تسألني عن شرح درس أو تطلب أفكارًا للمراجعة. في النسخة دي الردود تجريبية، ولسه ما اتوصلتش بخدمة ذكاء اصطناعي حقيقية.',
  ];
  @override
  void dispose() { input.dispose(); super.dispose(); }
  void send() {
    final q = input.text.trim();
    if (q.isEmpty) return;
    setState(() {
      messages.add('أنت: $q');
      messages.add('المساعد: وصلتني رسالتك. عند ربط خدمة الذكاء الاصطناعي، هقدر أساعدك في شرح السؤال أو تلخيص النص وإنشاء تدريبات. حاليًا دي واجهة تجريبية فقط.');
      input.clear();
    });
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('المساعد الذكي')),
    body: Column(children: [
      Expanded(child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: messages.length,
        itemBuilder: (context, i) {
          final user = messages[i].startsWith('أنت:');
          return Align(
            alignment: user ? Alignment.centerLeft : Alignment.centerRight,
            child: Container(
              constraints: const BoxConstraints(maxWidth: 320),
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: user ? const Color(0xFFE8EDFF) : Colors.white, borderRadius: BorderRadius.circular(16)),
              child: Text(messages[i], style: const TextStyle(height: 1.45)),
            ),
          );
        },
      )),
      SafeArea(child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          Expanded(child: TextField(controller: input, onSubmitted: (_) => send(), decoration: const InputDecoration(hintText: 'اكتب سؤالك هنا...', border: OutlineInputBorder(), filled: true, fillColor: Colors.white))),
          const SizedBox(width: 8),
          IconButton.filled(onPressed: send, icon: const Icon(Icons.send)),
        ]),
      )),
    ]),
  );
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});
  @override
  State<QuizPage> createState() => _QuizPageState();
}
class _QuizPageState extends State<QuizPage> {
  String? answer;
  bool checked = false;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('اختبار تجريبي')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('مثال على سؤال اختيار من متعدد', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 8),
      const Text('أي جزء في النبات يمتص الماء غالبًا من التربة؟', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      ...['الأوراق', 'الجذور', 'الزهرة', 'الثمرة'].map((v) => Card(
        elevation: 0,
        color: answer == v ? const Color(0xFFE8EDFF) : Colors.white,
        child: RadioListTile<String>(value: v, groupValue: answer, onChanged: checked ? null : (x) => setState(() => answer = x), title: Text(v)),
      )),
      const SizedBox(height: 12),
      if (checked) Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: answer == 'الجذور' ? const Color(0xFFE2F7EC) : const Color(0xFFFFE9E9), borderRadius: BorderRadius.circular(14)),
        child: Text(answer == 'الجذور' ? 'إجابة صحيحة! الجذور تمتص الماء والأملاح المعدنية من التربة.' : 'الإجابة الصحيحة هي: الجذور. راجع وظيفة الجذور ثم جرّب مرة أخرى.', style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
      const SizedBox(height: 12),
      FilledButton(onPressed: answer == null ? null : () => setState(() => checked = true), child: const Text('تحقق من الإجابة')),
      TextButton(onPressed: () => setState(() { answer = null; checked = false; }), child: const Text('إعادة الاختبار')),
      const Text('هذا سؤال تجريبي مضاف يدويًا؛ إنشاء الاختبارات من ملفات الطالب سيحتاج ربط محلل PDF والذكاء الاصطناعي.', style: TextStyle(color: Colors.black54, fontSize: 12)),
    ]),
  );
}

class StudyIllustration extends StatelessWidget {
  const StudyIllustration({super.key});
  @override
  Widget build(BuildContext context) => Container(
    height: 150,
    decoration: BoxDecoration(color: const Color(0xFFE8EDFF), borderRadius: BorderRadius.circular(24)),
    child: Stack(alignment: Alignment.center, children: [
      Positioned(right: 24, top: 22, child: Icon(Icons.star_rounded, size: 28, color: Colors.amber.shade700)),
      Positioned(left: 30, top: 30, child: Icon(Icons.auto_awesome, size: 24, color: blue)),
      Container(
        width: 190,
        height: 92,
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(color: Color(0x143155D5), blurRadius: 14, offset: Offset(0, 5))]),
        child: const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          Icon(Icons.menu_book_rounded, size: 38, color: blue),
          Icon(Icons.check_circle_rounded, size: 38, color: green),
          Icon(Icons.bar_chart_rounded, size: 38, color: Color(0xFFB7791F)),
        ]),
      ),
      Positioned(bottom: 10, child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5), decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(20)), child: const Text('خطتك على مقاسك', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)))),
    ]),
  );
}
